// Клиентский «Поделиться»: сохраняем lot и фон через /api/share, и ПАРАЛЛЕЛЬНО
// закрепляем текущий макет локально (для иконки на дом. экране).
import { state } from './state.js';
import { withLoading, showToastNear } from './utils.js';
import { savePinned } from './pinned.js';

async function imageElementToDataURL(imgEl) {
  if (!imgEl || !imgEl.src) return null;
  const src = imgEl.src;

  if (src.startsWith('data:')) return src;

  if (src.startsWith('blob:')) {
    await new Promise((res, rej) => {
      if (imgEl.complete && imgEl.naturalWidth) return res();
      imgEl.onload = () => res();
      imgEl.onerror = (e) => rej(e);
    });
    try {
      const w = imgEl.naturalWidth || imgEl.width || 1;
      const h = imgEl.naturalHeight || imgEl.height || 1;
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(imgEl, 0, 0, w, h);
      return canvas.toDataURL('image/png');
    } catch {
      return null;
    }
  }

  if (/^https?:\/\//i.test(src)) return src;
  return src;
}

async function buildPayload(refs) {
  const lot = state.lastLottieJSON;
  if (!lot) throw new Error('Нет данных Lottie');

  let bg = null;
  const imgEl = refs?.bgImg;
  if (imgEl && imgEl.src) {
    const maybeData = await imageElementToDataURL(imgEl);
    if (maybeData && maybeData.startsWith('data:')) {
      bg = { kind: 'data', value: maybeData };
    } else if (maybeData) {
      bg = { kind: 'url', value: maybeData };
    }
  }

  const opts = { loop: !!state.loopOn, autoplay: !!state.autoplayOn };
  return { lot, bg, opts };
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); return true; }
    catch { return false; }
    finally { document.body.removeChild(ta); }
  }
}

export function initShare({ refs /*, isStandalone*/ }) {
  const btn = refs?.shareBtn;
  if (!btn) return;

  btn.addEventListener('click', async () => {
    await withLoading(btn, async () => {
      const payload = await buildPayload(refs);

      // 1) Сохраняем на сервер (для короткой ссылки)
      const res = await fetch('/api/share', {
        method: 'POST',
        headers: { 'content-type': 'application/json; charset=utf-8' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const t = await res.text().catch(() => '');
        throw new Error(`share failed: ${res.status}${t ? ' ' + t : ''}`);
      }
      const { id } = await res.json();
      const shortUrl = `${location.origin}/s/${id}`;

      // 2) Параллельно закрепляем локально для A2HS (если ярлык грузит базовый URL)
      savePinned(payload);

      await copyToClipboard(shortUrl);
      showToastNear(refs.toastEl, btn, 'Ссылка скопирована');
    });
  });
}
